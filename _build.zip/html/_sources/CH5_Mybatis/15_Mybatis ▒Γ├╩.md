# 15 Mybatis 기초

## 15.1 Mybatis 란?

 * MyBatis는 개발자가 지정한 SQL 저장 프로시저 그리고 몇 가지 고급 매핑을 지원하는 퍼시스턴스 프레임워크다.
 * MyBatis는 JDBC로 처리하는 상당 부분의 코드와 파라미터 설정 및 결과 매핑을 대신해준다. Mybatis는 데이터베이스 레코드에 원시타입과 Map인터페이스 그리고 자바 POJO를 설정해서 매핑하기 위해 XML과 어노테이션을 사용할 수 있다.
 * `iBatis는 MyBatis`의 구버전이다. 
 * iBatis에서 MyBatis로 변경된 이유는 Apache project팀에서 google code 팀으로 이동하면서 명칭이 변경된 것이다.


## 15.2 MyBatis 적용 예제 만들기

### 15.2.1 프로젝트 기본형 만들기

* 책에서 oracle을 사용했지만, 이 장에선 대신 `오픈소스인 mariadb`를 사용했음  
:::{admonition}  마리아DB설치 및 sql tool 다운로드  
  mariadb 설치 https://leirbag.tistory.com/46  
  toad for mysql 8.0 다운로드 [링크 클릭 ](https://drive.google.com/drive/folders/1qCOOWMsAjKsU9YhgOdkCXK7T7FLr19UY?usp=sharing)  
:::
  
* 테이블 및 데이터 등록  (한글설정을 해줘야 함)
  ```sql
    #테이블 생성 
    drop table myuser;

    create table myuser(
    id varchar(10),
    name varchar(10)
    
    )
    #데이터베이스 한글 설정
    alter database test default character set utf8;
    #테이블 한글 설정
    alter table myuser convert to CHARACTER set utf8;
    # 샘플 데이터 추가
    insert into myuser values ('test1', '홍길동1');
    insert into myuser values ('test2', '홍길동2');
    insert into myuser values ('test3', '홍길동3');


  ```
  ![](images/15-1.jpg)  
* JDBC API, Lombok, MariaDB Driver, Mybatis Framework, Spring Web 선택  
  ![](images/15-2.jpg)  
* jsp에서 사용할 jstl과 jsp dependency 추가  
  ![](images/15-3.jpg)  
* Gradle > Gradle Project Refresh 수행  
* application.properties 작성
``` properties
server.port=8081

#JSP
spring.mvc.view.prefix=/WEB-INF/views/
spring.mvc.view.suffix=.jsp

# Mysql datasource settings
spring.datasource.url=jdbc:mariadb://localhost:3306/test?characterEncoding=UTF-8&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=1
spring.datasource.driver-class-name=org.mariadb.jdbc.Driver


#mybatis
mybatis.mapper-locations=classpath:mybatis/mapper/**/**.xml
```

### 15.2.2 DTO, DAO 추가
* MyUserDTO.java 클래스 작성
``` java
package com.study.springboot.jdbc;

import lombok.Data;

@Data
public class MyUserDTO {

	private String id;
	private String name;
}

```
* IMyUserDao.java 인터페이스 작성
* `@Mapper 어노테이션은 다음 인터페이스를 구현을 XML로 한다는 의미이다.`
``` java
package com.study.springboot.jdbc;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface IMyUserDao {
	List<MyUserDTO> list();
}

```

### 15.2.3 매퍼구현  
  
* resources 아래 매퍼파일을 저장할 패키지 생성  
  ![](images/15-4.jpg)  
* 매퍼파일을 xml 파일로 생성  

  ![](images/15-5.jpg)  
* select id ="list"의 id는 IMyUserDao 인터페이스에 정의된 이름 입니다.
```xml
<?xml version="1.0" encoding="UTF-8"?>

<!DOCTYPE mapper
	PUBLIC "-//mybatis.org/DTD Mapper 3.0//EN"
	"http://mybatis.org/dtd/mybatis-3-mapper.dtd">
	
<mapper namespace="com.study.springboot.jdbc.IMyUserDao">
	<select id="list" resultType="com.study.springboot.jdbc.MyUserDTO">
		select id, name from myuser
	</select>
</mapper>
	
```

### 15.2.4 리퀘스트 매핑
* MyController 클래스에 코드를 작성해 URL 호출에 대한 리퀘스트 매핑을 한다.  
``` java
package com.study.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.study.springboot.jdbc.IMyUserDao;

@Controller
public class MyController {
    
    @Autowired
    private IMyUserDao userDao;
    
    @RequestMapping("/")
    public @ResponseBody String root() throws Exception{
        return "Mybatis 사용하기";
    }
    
    @RequestMapping(value= "/user", method = RequestMethod.GET)
    public String userlistPage(Model model) {
        model.addAttribute("users",  userDao.list());
        return "userlist";
    }
}
```
* userlistPage 메소드는 /user url입력시 호출되고, `userDao인터페이스의 list()메소드를 호출해 결과값을 users`에 담아 리턴한다.

### 15.2.5 뷰 만들기
```jsp
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>   
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html" charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
 <%
 	out.println("Mybatis : Hello World");
 %>
 <br>
 
 <c:forEach var="dto" items="${users}">
 	${dto.id} / ${dto.name}<br>
 </c:forEach>
</body>
</html>

```
* 3라인에서 jstl 태그 라이브러리를 추가함
* 모델의 users 속성에 리스트를 담아 두었기 때문에 `<c:forEach var="dto" items="${users}"> ` 를 사용해 dto를 하나씩 꺼내서 내용을 출력한다

### 15.2.6 테스트
* 호출 순서 `webpage url >  Mycontroller.userlistPage > IMyUserDao > MyUserDao.xml > Mycontroller.userlistPage > userlist.jsp`
![](images/15-6.jpg)  
![](images/15-7.jpg) 
