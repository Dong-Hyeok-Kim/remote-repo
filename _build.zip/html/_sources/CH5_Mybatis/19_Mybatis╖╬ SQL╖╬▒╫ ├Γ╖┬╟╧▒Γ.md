# 19 Mybatis로 SQL로그 출력하기

## 19.1  스프링 부트와 로깅
* 자바 로깅 프레임워크  
  * log4j
  * logback
  * log4j2
  * apache common logging
  * SLF4J 등  
* 스프링 부트는 logback을 기본적인 로깅 시스템으로 지원
* 스프링 부투에서 logback을 사용하기 위해 별도 추가 디펜던시는 없고, application.properties를 통한 로깅 설정 할 수 있고, xml 파일을 따로 설정 정보를 관리할 수 있다.
* 로깅 커스트마이징을 사용할 경우 logback.xml 파일을 resources 디렉토리에 만들어 참조한다.
* logback은 이 설정 파일을 자동으로 찾는데 logback.groovy --> logback-test.xml --> logback.xml 순서로 찾고 없으면 디폴트 설정을 따른다
* 스프링 부트의 경우 조금 다르게 logback.xml 이라는 이름 대신, logback-spring.xml을 사용한다.  

## 19.2  MyBatis에 로깅 시스템 적용한 예제
* MyBatis를 사용하면 편한데, SQL관련해서 로그를 출력해 볼 수가 없다.
  
### 19.2.1 프로젝트 복사하기  
* Ex15_MyBatis 프로젝트를 복사해서 붙여 넣고, Ex19_SqlLog 로 이름을 변경한다.
* .project와 settings.gradle을 열고 프로젝트명을 Ex19_SqlLog 로 변경  
  
`.project 변경`
``` properties
<?xml version="1.0" encoding="UTF-8"?>
<projectDescription>
	<name>Ex19_SqlLog</name>
	<comment>Project Ex19_SqlLog created by Buildship.</comment>
	<projects>
	</projects>
	<buildSpec>
		<buildCommand>
			<name>org.eclipse.jdt.core.javabuilder</name>
			<arguments>
			</arguments>
```
`settings.gradle 변경`
``` properties
rootProject.name = 'Ex19_SqlLog'
```

### 19.2.2 프로젝트 임포트
* STS에서 프로젝트를 임포트해서 클래스를 선택 후 우클릭 > Refactor > Rename을 선택해 Ex19SqlLogApplication으로 변경  

### 19.2.3 로깅 설정 파일 추가
* `src/main/resources 에 logback-spring.xml 파일을 새로 만들어 추가한다.`
`logback-spring.xml 생성`
``` xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
	<appender name="console" class="ch.qos.logback.core.ConsoleAppender">
		<encoder>
			<Pattern>[%d{yyyy-MM-dd HH:mm:ss}:%-3relative] [%thread] %-5level %logger{36} - %msg%n</Pattern>
		</encoder>
	</appender>		
	
	<logger name="com.study.springboot" level="debug" />
	
	<root level="info">
		<appender-ref ref="console"/>
	</root>
</configuration>
```
* appender에서 지정하는 클래스에 따라 로그 출력방법을 콘솔, 파일, DB,메일로 정할 수 있다. 여기선 콘솔에 출력하고 어펜더 이름을 console로 한다.
* Pattern 태그로  로그 출력 패턴을 지정한다
* 프로그램 전체적으로 info 로그레벨을 설정한다.
* com.study.springboot 하위 부분에 대해서는 debug 로그레벨을 설정한다.  

### 19.2.4 테스트
* http://localhost:8081 호출 시엔 INFO 로그 레벨
* http://localhost:8081/user 호출 시엔 DEBUG 로그 레벨
![](images/19-1.jpg)  

## 19.3 SQL 쿼리문의 다양한 로그 출력  
### 19.3.1 로깅 설정 파일 추가, 수정  
* `src/main/resources 에 log4jdbc.log4j2.properties 파일을 새로 만들어 추가한다.`
`log4jdbc.log4j2.properties 생성`
``` properties
log4jdbc.spylogdelegator.name=net.sf.log4jdbc.log.slf4j.Slf4jSpyLogDelegator
log4jdbc.dump.sql.maxlinelength=0
```
`logback-spring.xml 수정`
``` xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
	<appender name="console" class="ch.qos.logback.core.ConsoleAppender">
		<encoder>
			<Pattern>[%d{yyyy-MM-dd HH:mm:ss}:%-3relative] [%thread] %-5level %logger{36} - %msg%n</Pattern>
		</encoder>
	</appender>		
	
	<logger name="com.study.springboot" level="info" />

	<!-- log4j2-jdbc4 -->
	<logger name="jdbc" level="OFF" />
	<logger name="jdbc.sqlonly" level="OFF" />
	<logger name="jdbc.sqltiming" level="DEBUG" />
	<logger name="jdbc.resultset" level="OFF" />
	<logger name="jdbc.resultsettable" level="DEBUG" />
	<logger name="jdbc.connection" level="OFF" />
	<!-- log4j2-jdbc4 -->
	
	<root level="off">
		<appender-ref ref="console"/>
	</root>
</configuration>
```
### 19.3.2 application.properties 수정 
`application.properties 수정`
``` properties
server.port=8081

#JSP
spring.mvc.view.prefix=/WEB-INF/views/
spring.mvc.view.suffix=.jsp

# Mysql datasource settings
#spring.datasource.url=jdbc:mariadb://localhost:3306/test?characterEncoding=UTF-8&serverTimezone=UTC
#spring.datasource.driver-class-name=org.mariadb.jdbc.Driver
spring.datasource.url=jdbc:log4jdbc:mariadb://localhost:3306/test?characterEncoding=UTF-8&serverTimezone=UTC
spring.datasource.driver-class-name=net.sf.log4jdbc.sql.jdbcapi.DriverSpy
spring.datasource.username=root
spring.datasource.password=1



#mybatis
mybatis.mapper-locations=classpath:mybatis/mapper/**/**.xml

```
### 19.3.3 build.gradle 수정 
* implementation 'org.bgee.log4jdbc-log4j2:log4jdbc-log4j2-jdbc4:1.16' 추가  

![](images/19-2.jpg)  
* Gradle 파일 수정되었으니, Gradel > Gradle Project Refresh 수행

### 19.3.4 테스트
* http://localhost:8081/user 호출 시 `sql 문과 쿼리 수행시간, ResultSet`이 출력 된다.

![](images/19-3.jpg)  