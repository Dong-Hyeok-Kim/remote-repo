# 18 Mybatis에서 쿼리 결괏값 사용하기

## 18.1  Mybatis에서 SQL쿼리 결괏값 사용하기
* MyBatis에서 SQL쿼리가 성공하면 다음과 같은 결괏값을 얻을 수 있다
  * Select - Selet문에 해당하는 결과
  * Insert - 1 (여러 개일 경우도 1)
  * Update - Update된 행의 개수 반환 (없다면 0)
  * Delete - Delete된 행의 개수(없다면 0)

### 18.1.1 프로젝트 복사하기
* Ex17_MyBatis_Param 프로젝트를 복사해서 붙여 넣고, Ex18_MyBatis_ResultNum 으로 이름을 변경한다.
* .project와 settings.gradle을 열고 프로젝트명을 Ex18_MyBatis_ResultNum 으로 변경  
  
`.project 변경`
``` properties
<?xml version="1.0" encoding="UTF-8"?>
<projectDescription>
	<name>Ex18_MyBatis_ResultNum</name>
	<comment>Project Ex18_MyBatis_ResultNum created by Buildship.</comment>
	<projects>
	</projects>
	<buildSpec>
		<buildCommand>
			<name>org.eclipse.jdt.core.javabuilder</name>
			<arguments>
			</arguments>
```
`settings.gradle 변경`
``` properties
rootProject.name = 'Ex18_MyBatis_ResultNum'
```
### 18.1.2 프로젝트 임포트
* STS에서 프로젝트를 임포트해서 클래스를 선택 후 우클릭 > Refactor > Rename을 선택해 Ex18MyBatisResultNumApplication으로 변경  

### 18.1.3 DAO, mapper에서 파라미터 부분 변경
`ISimpleBbsDao.java 변경`
``` java
package com.study.springboot.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.study.springboot.dto.SimpleBbsDto;

@Mapper
public interface ISimpleBbsDao {

	public List<SimpleBbsDto> listDao();
	public SimpleBbsDto viewDao(String id);
	public int writeDao(Map<String, String> map);   //변경
	public int deleteDao(@Param("_id") String id);
	public int articleCount();                      //추가
}
```

`SimpleBbsDao.xml 변경`
``` xml
<?xml version="1.0" encoding="UTF-8"?>

<!DOCTYPE mapper
	PUBLIC "-//mybatis.org/DTD Mapper 3.0//EN"
	"http://mybatis.org/dtd/mybatis-3-mapper.dtd">
	
<mapper namespace="com.study.springboot.dao.ISimpleBbsDao">

	<select id="listDao" resultType="com.study.springboot.dto.SimpleBbsDto">
		select * from simple_bbs order by id desc
	</select>
	

	<select id="viewDao" resultType="com.study.springboot.dto.SimpleBbsDto">
		select * from simple_bbs where id =#{0}
	</select>	
<!-- insert문 파라미터 HashMap으로 변경 -->
	<insert id="writeDao" parameterType="java.util.HashMap" >
		insert into simple_bbs( writer, title, content)
			values ( #{item1}, #{item2}, #{item3})
	</insert>
	
	<delete id="deleteDao">
		delete from simple_bbs where id = #{_id}
	</delete>

<!-- 건수 조회 추가 -->	
	<select id="articleCount" resultType="_int">
		select count(*) from simple_bbs
	</select>
</mapper>
```

:::{admonition} 자주 사용하는 타입과 예약된 별칭  
|**`별칭(alias)`**|데이터 타입| |**`별칭(alias)`**|데이터 타입|
|:---|:---|:---|:---|:---|
|**`_boolean`**| boolean| | **`float     `** | Float|
|**`_byte   `**| byte   | | **`double    `** | Double|
|**`_short  `**| short  | | **`object    `** | Object|
|**`_int    `**| int    | | **`string    `** | String|
|**`_long   `**| long   | | **`date      `** | Date|
|**`_float  `**| float  | | **`map       `** | Map|
|**`_double `**| double | | **`hashmap   `** | HashMap|
|**`boolean `**| Boolean| | **`list      `** | List|
|**`byte    `**| Byte   | | **`arraylist `** | ArrayList|
|**`short   `**| Short  | | **`collection`** | Collection|
|**`int     `**| Integer| | **`iterator  `** | Iterator|
|**`long    `**| Long   | | **`ResultSet `** | ResultSet| 
:::  

### 18.1.4 컨트롤러 부분 변경
`MyController.java 변경`

```java
package com.study.springboot;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.study.springboot.dao.ISimpleBbsDao;

@Controller
public class MyController {

	@Autowired
	ISimpleBbsDao dao;
	
	@RequestMapping("/")
	public String root() throws Exception{
		//Mybatis : SimpleBBS
		return "redirect:list";
	}
	
	@RequestMapping("/list")
	public String userlistpage(Model model) {
		model.addAttribute("list", dao.listDao());
		
		int nTotalCount = dao.articleCount();           //글목록 건수 조회 추가
		System.out.println("Count : " + nTotalCount);
		
		return "/list";
	}
	
	@RequestMapping("/view")
	public String view(HttpServletRequest request, Model model) {
		String sId = request.getParameter("id");
		model.addAttribute("dto", dao.viewDao(sId));
		return "/view";
	}
	
	@RequestMapping("/writeForm")
	public String writeForm() {
		return "/writeForm";
	}
	
	@RequestMapping("/write")
	public String write(HttpServletRequest request, Model model) {
		
		/* HashMap 파라미터 설정 추가*/
		String sName = request.getParameter("writer");
		String sTitle = request.getParameter("title");
		String sContent = request.getParameter("content");
		
		Map<String, String> map = new HashMap<String, String>();
		
		map.put("item1", sName);
		map.put("item2", sTitle);
		map.put("item3", sContent);
		
		int nResult = dao.writeDao(map);
		System.out.println("Write : " + nResult);  //insert 결과 추가
		
		return "redirect:list";						
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request, Model model) {
		
		String sId = request.getParameter("id");
		int nResult = dao.deleteDao(sId);
		System.out.println("Delete : " + nResult);  //delete 결과 추가
		
		return "redirect:list";
	}
}

```

### 18.1.5 테스트
* 호출 순서 list > writeForm > list > Delete > list 
* list 보기 > 글작성 > list 보기 > 삭제 > list 보기  

![](images/18-1.jpg)  
 