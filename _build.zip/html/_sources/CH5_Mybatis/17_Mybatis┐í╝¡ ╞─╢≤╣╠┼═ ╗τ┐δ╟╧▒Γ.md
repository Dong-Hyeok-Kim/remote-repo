# 17 Mybatis에서 파라미터 사용하기

## 17.1  Mybatis에서 파라미터 사용하기
* Mybatis에서 SQL문에 파라미터를 전달하는 방법은 아래 4가지로 정리할 수 있음
* **`방법1`** param1, param2, param3 ... 과 같이 param 변수 뒤에 숫자를 늘려 가면서 #{}사이에 적어서 사용
``` sql
<select>
	select * from 테이블명 where 컬럼=#{param1} and 컬럼=#{param2}
</select>
```
* **`방법2`** 0부터 시작하는 인텍스를 사용해 #{}사이에 적어준다. 작성할 때는 편하나, 나중에 이 항목이 어떤 항목이었는지 파악하기 쉽지 않다.
``` sql
<select>
	select * from 테이블명 where 컬럼=#{0} and 컬럼=#{1}
</select>
```
* **`방법3`** 지정한 파라미터명을 사용하기 위해 @Param 어노테이션을 사용해 이름을 지정해주는 방법. 작성할 때 번거로울 수 있으나, 나중에 이 항목이 어떤 항목이었는지 파악하기 쉽다
``` sql
인터페이스 추상메서드 정의 시
	public void 함수명(@Param("파라미터명")String 파라미터명 ...)

Mapper 파일에서
	select * from 테이블명 where 필드명=#{파라미터명}
으로 사용할 수 있다.
```
* **`방법4`** 다량의 데이터를 파라미터로 받을 때 해시맵을 사용해 받는 방법. 
``` sql
인터페이스 추상메서드 정의 시
	public int writeDao(Map <String, String> 파라미터명);

Controller 파일에서
	Map<String, String> map = new HashMap <String, String>();
	map.put("item1",sName);
	map.put("item2",sContent);

Mapper 파일에서
	insert into simple_bbs(id, writer, content)
		values (1, #{item1}, #{item2})
으로 사용 할 수 있다.
```
## 17.2  Mybatis에서 파라미터 사용 예제 만들기

### 17.2.1 프로젝트 복사하기
* Ex16_MyBatis_SimpleBBS 프로젝트를 복사해서 붙여 넣고, Ex17_MyBatis_Param으로 이름을 변경한다.
* .project와 settings.gradle을 열고 프로젝트명을 EX17_MyBatis_Param으로 변경  
  
`.project 변경`
``` properties
<?xml version="1.0" encoding="UTF-8"?>
<projectDescription>
	<name>Ex17_MyBatis_Param</name>
	<comment>Project Ex17_MyBatis_Param created by Buildship.</comment>
	<projects>
	</projects>
	<buildSpec>
		<buildCommand>
			<name>org.eclipse.jdt.core.javabuilder</name>
			<arguments>
			</arguments>
```
`settings.gradle 변경`
``` properties
rootProject.name = 'Ex17_MyBatis_Param'
```
### 17.2.2 프로젝트 임포트
* STS에서 프로젝트를 임포트해서 클래스를 선택 후 우클릭 > Refactor > Rename을 선택해 Ex17MyBatisParamApplication으로 변경

### 17.2.3 DAO, mapper에서 파라미터 부분 변경
`ISimpleBbsDao.java 변경`
``` java
package com.study.springboot.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.study.springboot.dto.SimpleBbsDto;

@Mapper
public interface ISimpleBbsDao {

	public List<SimpleBbsDto> listDao();
	public SimpleBbsDto viewDao(String id);
	public int writeDao(String writer, String title, String content);
	public int deleteDao(@Param("_id") String id);
}
```
`SimpleBbsDao.xml 변경`
``` xml
<?xml version="1.0" encoding="UTF-8"?>

<!DOCTYPE mapper
	PUBLIC "-//mybatis.org/DTD Mapper 3.0//EN"
	"http://mybatis.org/dtd/mybatis-3-mapper.dtd">
	
<mapper namespace="com.study.springboot.dao.ISimpleBbsDao">

	<select id="listDao" resultType="com.study.springboot.dto.SimpleBbsDto">
		select * from simple_bbs order by id desc
	</select>
	

	<select id="viewDao" resultType="com.study.springboot.dto.SimpleBbsDto">
		select * from simple_bbs where id =#{0}  <!-- 변경 -->
	</select>	

	<insert id="writeDao" >
		insert into simple_bbs( writer, title, content)
			values ( #{param1}, #{param2}, #{param3})
	</insert>
	
	<delete id="deleteDao">
		delete from simple_bbs where id = #{_id}  <!-- 변경 -->
	</delete>
</mapper>

```

### 17.2.4 테스트
* 호출 순서 list > writeForm > list > view > list 
* list 보기 > 글작성 > list 보기 > 글작성 > list 보기 > 내용 보기 > list 보기 > 글 삭제 > list 보기  
 
![](images/17-1.jpg)  