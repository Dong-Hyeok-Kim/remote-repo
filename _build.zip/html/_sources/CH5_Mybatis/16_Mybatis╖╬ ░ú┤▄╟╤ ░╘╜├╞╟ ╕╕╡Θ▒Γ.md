# 16 Mybatis로 간단한 게시판 만들기

## 16.1 Mybatis를 이용한 간단한 게시판 만들기
* Mybatis를 이용한 CRUD 게시판 생성

### 16.1.1 프로젝트 기본형 만들기
* 책에서 oracle을 사용했지만, 이 장에선 대신 `오픈소스인 mariadb`를 사용했음
* mariadb 설치 https://leirbag.tistory.com/46
* toad for mysql 8.0 다운로드 [링크 클릭 ](https://drive.google.com/file/d/1wkns1ESjPmBt-GTrapaVgRtE1T6uEoie/view?usp=sharing)  
* 테이블 및 데이터 등록  (한글설정을 해줘야 함)
  ```sql
  drop table simple_bbs;

  #mariadb는 sequence가 없고, id가 예약어다. auto_increment를 이용해 sequence를 대체해 사용한다.
  create table simple_bbs(
  id  int not null primary key auto_increment,   
  writer varchar(100),
  title varchar(100),
  content varchar(100)
  
  );
  #데이터베이스 한글 설정
  alter database test default character set utf8;
  #테이블 한글 설정
  alter table simple_bbs convert to CHARACTER set utf8;


  ```
![](images/16-1.jpg)   
* JDBC API, Lombok, MariaDB Driver, Mybatis Framework, Spring Web 선택   
  
![](images/16-2.jpg)  
* jsp에서 사용할 jstl과 jsp dependency 추가   
  
![](images/16-3.jpg)  
* Gradle > Gradle Project Refresh 수행   
* application.properties 작성  
``` properties
server.port=8081

#JSP
spring.mvc.view.prefix=/WEB-INF/views/
spring.mvc.view.suffix=.jsp

# Mysql datasource settings
spring.datasource.url=jdbc:mariadb://localhost:3306/test?characterEncoding=UTF-8&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=1
spring.datasource.driver-class-name=org.mariadb.jdbc.Driver


#mybatis
mybatis.mapper-locations=classpath:mybatis/mapper/**/**.xml
```

### 16.1.2 DTO, DAO mapper 추가
* SimpleBbsDto.java 클래스 작성  
``` java
package com.study.springboot.dto;

import lombok.Data;

@Data
public class SimpleBbsDto {
	
	private int id;
	private String writer;
	private String title;
	private String content;
}
```
* ISimpleBbsDao.java 인터페이스 작성
* @Mapper 어노테이션은 다음 인터페이스를 구현을 XML로 한다는 의미이다.
``` java
package com.study.springboot.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.study.springboot.dto.SimpleBbsDto;

@Mapper
public interface ISimpleBbsDao {

	public List<SimpleBbsDto> listDao();
	public SimpleBbsDto viewDao(String id);
	public int writeDao(String writer, String title, String content);
	public int deleteDao(String id);
}
```

### 16.1.3 매퍼구현  
* resources 아래 매퍼파일을 저장할 패키지 생성  
* 매퍼파일을 xml 파일로 생성
* xml 파일의 id는 ISimpleBbsDao 인터페이스에 정의된 이름 입니다.
```xml
<?xml version="1.0" encoding="UTF-8"?>

<!DOCTYPE mapper
	PUBLIC "-//mybatis.org/DTD Mapper 3.0//EN"
	"http://mybatis.org/dtd/mybatis-3-mapper.dtd">
	
<mapper namespace="com.study.springboot.dao.ISimpleBbsDao">

	<select id="listDao" resultType="com.study.springboot.dto.SimpleBbsDto">
		select * from simple_bbs order by id desc
	</select>
	

	<select id="viewDao" resultType="com.study.springboot.dto.SimpleBbsDto">
		select * from simple_bbs where id =#{param1}
	</select>	

	<insert id="writeDao" >
		insert into simple_bbs( writer, title, content)
			values ( #{param1}, #{param2}, #{param3})
	</insert>
	
	<delete id="deleteDao">
		delete from simple_bbs where id = #{param1}
	</delete>
</mapper>
```
* mariadb는 sequence가 없기때문에 insert sql 수행시 id가 자동으로 증가되어 등록 됨.  

### 16.1.4 리퀘스트 매핑

* MyController 클래스에 코드를 작성해 URL 호출에 대한 리퀘스트 매핑을 한다.  
``` java
package com.study.springboot;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.study.springboot.dao.ISimpleBbsDao;

@Controller
public class MyController {

	@Autowired
	ISimpleBbsDao dao;
	
	@RequestMapping("/")
	public String root() throws Exception{
		//Mybatis : SimpleBBS
		return "redirect:list";
	}
	
	@RequestMapping("/list")
	public String userlistpage(Model model) {
		model.addAttribute("list", dao.listDao());
		return "list";
	}
	
	@RequestMapping("/view")
	public String view(HttpServletRequest request, Model model) {
		String sId = request.getParameter("id");
		model.addAttribute("dto", dao.viewDao(sId));
		return "view";
	}
	
	@RequestMapping("/writeForm")
	public String writeForm() {
		return "writeForm";
	}
	
	@RequestMapping("/write")
	public String write(HttpServletRequest request, Model model) {
		dao.writeDao(request.getParameter("writer")
				, request.getParameter("title")
				, request.getParameter("content"));
		
		return "redirect:list";						
	}
	
	@RequestMapping("/delete")
	public String delete(HttpServletRequest request, Model model) {
		System.out.println("delete");
		dao.deleteDao(request.getParameter("id"));
		
		return "redirect:list";
	}
}

```

### 16.1.5 뷰 만들기
* Ex14_SimpleBBS에서 작성한 JSP를 복사해서 현재 프로젝트에 붙여넣는다.


### 16.1.6 테스트
* 호출 순서 list > writeForm > list > view > list 
* list 보기 > 글작성 > list 보기 > 글작성 > list 보기 > 내용 보기 > list 보기 > 글 삭제 > list 보기  
 
![](images/16-4.jpg)  