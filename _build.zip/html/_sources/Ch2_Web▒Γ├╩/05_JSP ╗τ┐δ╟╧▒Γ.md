# 05 JSP 사용하기

## 5.1 JSP 사용하기
1. 스프링 부트에서 JSP를 사용할때 `jar 파일`로 만들면 JSP가 `동작하지 않음`.  
2. 프로젝트 생성 시 `war파일`로 만들면 내장 WAS로 실행하거나, 외부 WAS 배포시 `정상 작동 함`  
3. 내장 서버로 jetty 사용할 수 없고 deault 옵션인 톰캣을 사용한다.  


## 5.2 예제 만들기
### 5.2.1 프로젝트 만들기  
  ![](img/5-2.jpg)  
  ![](img/5-3.jpg)   
* build.gradle 파일을 열어서 아래 붉은색 박스 내용을 적는다.  
* 22번째 라인 jstl을 사용하기 위한 라이브러리 추가  
* 23번째 라인 톰켓이 jsp 파일을 컴파일 할 수 있도록 만들어주는 라이브러리 추가  
  ![](img/5-4.jpg)  
* 프로젝트명 or build.gradle 선택 > 우클릭 > 팝업 메뉴 > Gradle > Refesh Gradle Project  
* 위 명령을 통해 buil.gradle에 변경되 내용대로 12번 라인에서 `지정한 저장소에서` 라이브러리가 다운로드된다.  

* 스프링부트에선 JSP는 src/main/resources의 템플릿 폴더를 사용할 수 없어 직접 폴더를 만들고 지정해야 함.  
![](img/5-5.jpg)  
* jsp 파일은 생성할 위치에서 우클릭 > New > Other..하면 나오는 팝업에서 jsp 입력 후 선택하면 됩니다. jsp file이 안나오면, `04_정적리소스 사용하기` 참고하세요.  
* JSP를 사용할 수 있도록 application.properties 파일에 아래와 같이 작성한다.  
![](img/5-6.jpg)  
* 한글때문에 팝업이 뜨면 Save as UTF-8로 저장한다.

### 5.2.2 뷰 만들기
* test1.jsp와 test2.jsp 만들기

``` html
<!--test1.jsp -->
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
		out.println("Hello World");
%>
</body>
</html>
```

``` html
<!--test2.jsp -->
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<%
		out.println("Hello World (sub)");
%>
</body>
</html>
```

### 5.2.3 리퀘스트 맵핑
* `/Ex05_JspUse/src/main/java/com/study/springboot/` 에 MyController 클래스 만들기

``` java 

package com.study.springboot;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {

		@RequestMapping("/")
		public @ResponseBody String root() throws Exception{
			return "JSP in Gradle";
		}
		
		@RequestMapping("/test1")			// localhose:8081/test1
		public String test1() {
			System.out.println("test1");
			return "test1";					// 실제 호출 됨 /WEB-INF/views/test1.jsp
		}
		
		@RequestMapping("/test2")			// localhose:8081/test2
		public String test2() {
			System.out.println("test2");
			return "sub/test2";				// 실제 호출 됨 /WEB-INF/views/sub/test2.jsp
		}
}


```
- application.properties에서 설정한 대로 메서드의 리턴값을 사용해 아래와같이 결과를 리턴함 
  - spring.mvc.view.prefix + 메서드 리턴 값  + spring.mvc.view.suffix  
  - /WEB=INF/views/ + test1 + jsp 

### 5.2.4테스트
- gradle 프로젝트로 만들었기 때문에 build.gradle 파일 우클릭 > Gradle > Refresh Gradle Project를 클릭해보자.

- 로컬 서버 실행 해서 localhost:8081 입력 후 결과확인  
- localhost:8081/test1 입력후 결과 확인
- localhost:8081/test2 입력후 결과 확인
![](img/5-7.jpg)  

