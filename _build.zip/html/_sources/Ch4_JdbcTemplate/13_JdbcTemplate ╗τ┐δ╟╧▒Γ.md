# 13 JdbcTemplate 사용하기 
## 13.1 JdbcTemplate
* 오라클, MySQL, MariaDB등 다른 데이터 베이스로도 사용 가능하다.
* 반복적인 작업을 줄이기 위해 스프링에서는 JdbcTemplate을 제공한다.
* MariaDB를 사용하여 진행하였다. 아래 url에서 mariadb-java-client-2.7.3.jar를 다운받았다.
```html
https://downloads.mariadb.com/Connectors/java/connector-java-2.7.3/
```
* MariaDB 다운로드 후 MariaDB 터미널을 열고 아래 명령어를 입력한다. (coffee라는 데이터베이스가 만들어진다.)
```html
create database coffee;
```
* 박영 매니저가 공유해 준 TOAD 프로그램을 설치하여 위 데이터베이스 연결 후 사용.

* 아래 쿼리를 카피하여 테이블을 생성한다. (MariaDB에서는 varchar를 사용)

```html
drop table user;
create table myuser (
	id varchar(10),
	name varchar(10)

);

INSERT into myuser  values ('test1', '홍길동1');
INSERT into myuser  values ('test2', '홍길동2');
INSERT into myuser  values ('test3', '홍길동3');
```

## 13.2 데이터베이스 사용 예제 만들기
## 13.2.1 프로젝트 생성
* Ex13_JdbcTemplate인 프로젝트를 생성한다.
 ![](images/13-1.jpg)  

## 13.2.2 디펜던시 추가
* Spring Web, Lombok, MariaDB Driver를 추가 한다.
 ![](images/13-2.jpg)  
* 책에서 검색되지 않아 체크하지 못했다고는 하는데 일단 검색하면 나온다. 체크해서 확인하면 책에 나와있는 MySQL 의존성 세팅과 같이 runtimeOnly 'org.mariadb.jdbc:mariadb-java-client'가 추가된다.
* 책에 나와있는 MariaDB 의존성 세팅은 아래와 같다.
```html
dependencies {
	implementation 'org.springframework.boot:spring-boot-starter-jdbc'
	implementation 'org.springframework.boot:spring-boot-starter-web'
	compileOnly 'org.projectlombok:lombok'
	annotationProcessor 'org.projectlombok:lombok'
	providedRuntime 'org.springframework.boot:spring-boot-starter-tomcat'
	testImplementation ('org.springframework.boot:spring-boot-starter-test'){
        exclude group: 'org.junit.vintage', module: 'junit-vintage-engine'
    }
    compile group: 'org.mariadb.jdbc', name: 'mariadb-java-client', version: '2.7.0'
}
```

## 13.2.6 JSP 사용을 위한 환경설정
* build.gradle을 수정한다. (아래 내용 추가 및 Gradle Project Refresh)
```html
	implementation 'javax.servlet:jstl'
	implementation 'org.apache.tomcat.embed:tomcat-embed-jasper'
```
* application.properties에 아래 내용을 추가한다.
```html
server.port=8081
#JSP
spring.mvc.view.prefix=/WEB-INF/views/
spring.mvc.view.suffix=.jsp
```
* 폴더를 생성한다. webapp>WEB-INF>views
* MyController.java를 생성한다.

## 13.2.7 JDBC 세팅 추가
* application.properties를 열고 아래 내용을 입력한다.
```html
#MariaDB set
spring.datasource.driver-class-name=org.mariadb.jdbc.Driver
spring.datasource.url=jdbc:mariadb://localhost:3306/coffee
spring.datasource.username=root
spring.datasource.password=112233!!
```
* db 명과 username과 패스워드를 입력한다.

## 13.2.8 DTO, DAO 추가
* 아래 그림과 같이 패키지와 클래스를 추가 한다.

![](images/13-3.jpg)

* MyUderDTO.java
```java
package com.study.springboot.jdbc;

import lombok.Data;

@Data
public class MyUserDTO {
	
	private String id;
	private String name;
}
```

* MyUserDAO.java
```java
package com.study.springboot.jdbc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MyUserDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<MyUserDTO> list(){
		String query = "select * from myuser";
		List<MyUserDTO> list = jdbcTemplate.query(
				query, new BeanPropertyRowMapper<MyUserDTO>(MyUserDTO.
						class));
		
		//for(UserDTO my :list){
			//System.out.println(my);
		//}
		
		return list;
	}
}
```
* @Repository 어노테이션은 이 클래스를 빈으로 등록하는데 데이터 베이스와 관련된 처리용도로 사용하겠다는 의미이다.
* private JdbcTemplate jdbcTemplate; 을 @Autowired 어노테이션을 이용하여 주입하였다.
* jdbcTemplate.query 메세드는 select 해온 결과를 로우마다 DTO 객체로 받아서 리스트 데이터로 만든다.

## 13.2.9 리퀘스트 맵핑

* MyController.java
```java
package com.study.springboot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.study.springboot.jdbc.MyUserDAO;

@Controller
public class MyController {
	
	@Autowired
	private MyUserDAO userDao;
	
	@RequestMapping("/")
	public @ResponseBody String root() throws Exception{
		return "JdbcTemplate 사용하기";
	}
	
	//@GetMapping("/user")
	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String userlistPage(Model model) {
		model.addAttribute("users", userDao.list());
		return "userlist";
	}

}
```
* @RequestMapping(value = "/user", method = RequestMethod.GET) 으로 호출방식을 지정해 준다.

## 13.2.10 뷰 만들기

* userlist.jsp
```jsp
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
</head>
<body>

<%
	out.println("JdbcTemplate : Hello World");
%>

<c:forEach var="dto" items="${users}">
	${dto.id } / ${dto.name }<br>
</c:forEach>
</body>
</html>
```

## 13.2.11 테스트
 ![](images/13-4.jpg)  
 ![](images/13-5.jpg)  