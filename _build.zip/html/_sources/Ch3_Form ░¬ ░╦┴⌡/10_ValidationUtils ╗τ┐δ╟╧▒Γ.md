# 10 ValidationUtils 사용하기

## 10.1 폼 데이터 유효성 검증 유틸리티 메서드 사용하기
* 개발자가 공통으로 개발하는 부분에 대한 공통 처리를 스프링에서는 API 메서드로 제공함

### 10.1.1 프로젝트 복사하기
 * `탐색기`에서 이전 프로젝트를 복사 후 붙여넣기한 후 프로젝트 명칭 변경
 * Ex09_Validator 복사 후 붙여넣기한 다음에 Ex10_ValidationUtils 로 명칭 수정

 ![](images/10-1.png)

 * Ex10_ValidatonUtils 프로젝트에 존재하는 **`.projects`** 및 **`settings.gradle`** 파일에 대해 텍스트 에디터로 파일을 열어서 프로젝트 명칭과 동일하게 문자열 수정

 ![](images/10-2.png)  

### 10.1.2 프로젝트 임포트
 * 메뉴에서 **`File > Import`** 를 선택한 후 Import 창에서 **`General > Existing Projects Into Workspace`** 메뉴를 선택한다.

 ![](images/10-3.png)
 ![](images/10-4.png)
  
 * Browse 버튼을 통해 앞서 생성한 Ex10_ValidationUtils 프로젝트를 임포트한다.

 ![](images/10-5.png)

* 기존 프로젝트의 흔적들이 아직 남아있는데, 이들에 대해서도 신규 프로젝트 기준으로 변경 해준다.
  * Ex09ValidatorApplication.java 파일명을 **`Refactor > Rename`** 메뉴를 이용해 수정한다.
  * **`Refactor > Rename`** 을 통해 수정하는 작업은 단순 파일명 변경이 아니라 파일 내부의 클래스 이름 변경 및 이 클래스를 참조하고 있는 관련된 파일들을 찾아서 그 안의 내용까지 자동으로 수정해주는 작업이다.
  * 테스트용 파일명도 변경할 것인지 묻는 창이 뜨면 **`Yes`** 를 선택해 변경해준다.

 ![](images/10-6.png)


### 10.1.3 유효성 검증 모듈 수정

* ContentValidator.java
``` java
package com.study.springboot;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

public class ContentValidator implements Validator {

	@Override
	public boolean supports(Class<?> arg0) {
		return ContentDto.class.isAssignableFrom(arg0);	// 검증할 객체의 클래스 타입 정보
	}
	
	@Override
	public void validate(Object obj, Errors errors) {
		
		ContentDto dto = (ContentDto)obj;
		
		/*
		1. 기존 코드 주석 처리 후 신규 코드 추가
		2. 개발자가 직접 작성하는 반복적인 작업에 대해 스프링 API에서 제공하는 
		   유틸 메서드를 사용 (데이터 검증 및 에러를 처리하는 것까지 포함)
		*/
//		String sWriter = dto.getWriter();
//		if ( sWriter == null || sWriter.trim().isEmpty() ) {
//			System.out.println("Writer is null or empty");
//			errors.rejectValue("writer", "trouble");
//		}
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "writer", "writer is empty");
		String sWriter = dto.getWriter();
		if ( sWriter.length() < 3 ) {
			errors.rejectValue("writer", "writer is too short.");
		}
		
//		String sContent = dto.getContent();
//		if ( sContent == null || sContent.trim().isEmpty() ) {
//			System.out.println("sContent is null or empty");
//			errors.rejectValue("content", "trouble");
//		}
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "content", "content is empty");
		
	}
	
}
```

### 10.1.4 리퀘스트 맵핑 수정

* MyController.java
``` java
package com.study.springboot;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {
	
	@RequestMapping("/")
	public  @ResponseBody String root() throws Exception {
		return "ValidationUtils (2)";	// 두 번째 예제 구분
	}

	@RequestMapping("/insertForm")
	public String insert1() {

		return "createPage";	// form 입력을 위한 :: createPage.jsp 호출
	}
	
	@RequestMapping("/create")
	public String insert2(@ModelAttribute("dto") ContentDto contentDto,
						BindingResult result)
	{
		String page = "createDonePage";	// form 입력 정상 :: createDonePage.jsp 호출
		System.out.println(contentDto);
		
		ContentValidator validator = new ContentValidator();
		validator.validate(contentDto, result);

		/*
		1. 이전 예제는 ContentValidator 클래스를 통해 유효성 검증 에러를 출력
		2. 이번에는 스프링에서 제공되는 API를 사용하면서 에러를 담은 결과(result)만 
		   리턴받기 때문에 MyController 클래스에서 에러를 출력
		*/
		if ( result.hasErrors() ) {
			System.out.println("getAllErrors : " + result.getAllErrors());
			
			if ( result.getFieldError("writer") != null ) {
				System.out.println("1:" + result.getFieldError("writer").getCode());				
			}
			if ( result.getFieldError("content") != null ) {
				System.out.println("2:" + result.getFieldError("content").getCode());				
			}

			page = "createPage";	// 에러가 있는 경우 :: createPage.jsp 호출
		}

		return page;
	}
}
```

### 10.1.5 테스트

* http://localhost:8081 실행 시 root() 메서드 호출되어 "Validator (2)" 결과만 반환

![](images/10-7.png)

* http://localhost:8081/insertForm 실행 후 유효성 검사 정상 처리 테스트

![](images/10-8.png)

* http://localhost:8081/insertForm 실행 후 유효성 검사 에러 처리 테스트

![](images/10-9.png)

* 콘솔 로그에 출력된 결과 참고

![](images/10-10.png) 
