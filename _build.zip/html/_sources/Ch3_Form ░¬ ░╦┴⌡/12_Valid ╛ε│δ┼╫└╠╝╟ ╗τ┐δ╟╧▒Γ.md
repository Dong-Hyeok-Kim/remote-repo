# 12 Valid 어노테이션 사용하기 
### 12.1 유효성 검증 관련 어노테이션 사용하기
* 앞선 Ex11_Valid_initBinder 까지는 우리가 직접 만든 클래스를 통해서 데이터의 유효성을 검증했으나, 검증 내용은 단순하고 전형적인 NULL, 공백 등을 체크하는 간단한 수준임
* 스프링에서 제공하는 데이터 체크 알고리즘을 통해 간단하게 처리할 수 있음.

### 12.1.1 프로젝트 복사하기
* 11.1.1 을 참고해서 프로젝트를 복사한다.
  * `탐색기`에서 이전 프로젝트를 복사 후 붙여넣기한 후 프로젝트 명칭 변경
  * Ex11_Valid_initBinder 복사 후 붙여넣기한 다음에 Ex12_Valid_Annotation 으로 명칭 수정 
  * Ex12_Valid_Annotation 프로젝트에 존재하는 **`.projects`** 및 **`settings.gradle`** 파일에 대해 텍스트 에디터로 파일을 열어서 프로젝트 명칭과 동일하게 문자열 수정


### 12.1.2 프로젝트 임포트
* 11.1.2 를 참고해서 프로젝트를 임포트한다.
  * 메뉴에서 **`File > Import`** 를 선택한 후 Import 창에서 **`General > Existing Projects Into Workspace`** 메뉴를 선택한다.
  * Browse 버튼을 통해 앞서 생성한 복사해서 생성한 Ex12_Valid_Annotation 프로젝트를 임포트한다.

### 12.1.3 유효성 검증 클래스 제거
* 스프링에서 제공하는 유 효성 검증 모듈을 사용할 것이므로, 기존에 만들어서 추가한 클래스를 프로젝트로부터 제거한다.
* `ContentValidator.java` 파일을 삭제함

### 12.1.4 폼 데이터의 유효성 검증을 위해 스프링의 어노테이션 적용

* ContentDto.java

```java
package com.study.springboot;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class ContentDto {	
	
	/*
	1. 유효성 검증의 정의를 어노테이션으로 지정
	*/

	private int id;

	@NotNull(message="writer is null.")		// NULL 체크
	@NotEmpty(message="writer is empty.")	// 공백 체크
	@Size(min=3, max=10, message="writer min 3, max 10.")	// 길이(3~10) 체크
	private String writer;

	@NotNull(message="content is null.")	// NULL 체크
	@NotEmpty(message="content is empty.")	// 공백 체크
	private String content;
}
```

* MyController.java

```java
package com.study.springboot;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {
	
	@RequestMapping("/")
	public  @ResponseBody String root() throws Exception {
		return "Valid_Annotation (4)";	// 네 번째 예제 구분
	}

	@RequestMapping("/insertForm")
	public String insert1() {

		return "createPage";	// form 입력을 위한 :: createPage.jsp 호출
	}
	
	@RequestMapping("/create")
	public String insert2(@ModelAttribute("dto") @Valid ContentDto contentDto,
						BindingResult result)
	{
		String page = "createDonePage";	// form 입력 정상 :: createDonePage.jsp 호출
		System.out.println(contentDto);
		
//		ContentValidator validator = new ContentValidator();
//		validator.validate(contentDto, result);

		if ( result.hasErrors() ) {
//			if ( result.getFieldError("writer") != null ) {
//				System.out.println("1:" + result.getFieldError("writer").getCode());				
//			}
//			if ( result.getFieldError("content") != null ) {
//				System.out.println("2:" + result.getFieldError("content").getCode());				
//			}

			/*
			2. 에러가 있을 때 result 객체로부터 에러 코드 대신 에러 메시지를 가져옴
			*/
			if ( result.getFieldError("writer") != null ) {
				System.out.println("1:" + result.getFieldError("writer").getDefaultMessage());				
			}
			if ( result.getFieldError("content") != null ) {
				System.out.println("2:" + result.getFieldError("content").getDefaultMessage());				
			}

			page = "createPage";	// 에러가 있는 경우 :: createPage.jsp 호출
		}

		return page;
	}
	
	/*
	1. 기존에 지정한 @initBinder 를 사용하지 않고 스프링에서 제공하는 
	   데이터 유효성 검증 모듈을 사용할 것임
	*/
//	@InitBinder
//	protected void initBinder(WebDataBinder binder) {
//		binder.setValidator(new ContentValidator());
//	}
}
```

### 12.1.5 테스트

* http://localhost:8081 실행 시 root() 메서드 호출되어 "Validator (4)" 결과만 반환

![](images/12-1.png)

* http://localhost:8081/insertForm 실행 후 유효성 검사 정상 처리 테스트

![](images/12-2.png)

* http://localhost:8081/insertForm 실행 후 유효성 검사 에러 처리 테스트

![](images/12-3.png)

* 콘솔 로그에 출력된 결과 참고

![](images/12-4.png)