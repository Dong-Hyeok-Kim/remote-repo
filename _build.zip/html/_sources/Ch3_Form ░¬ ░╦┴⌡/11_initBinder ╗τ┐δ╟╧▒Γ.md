# 11 initBinder 사용하기
## 11.1 유효성 검증 클래스의 약한 결함
* 앞선 Ex10_ValidationUtils는 구조상 검증이 필요할 때마다 검증용 클래스를 new 해서 사용해야 하며, 이런 경우를 **`강한 결합`** 이라 한다.
* 이에 대해 **`약한 결합`** 을 사용하는 구조로 변경한다.

### 11.1.1 프로젝트 복사하기
* 10.1.1 을 참고해서 프로젝트를 복사한다.
  * `탐색기`에서 이전 프로젝트를 복사 후 붙여넣기한 후 프로젝트 명칭 변경
  * Ex10_ValidationUtils 복사 후 붙여넣기한 다음에 Ex11_Valid_initBinder 로 명칭 수정 
  * Ex11_Valid_initBinder 프로젝트에 존재하는 **`.projects`** 및 **`settings.gradle`** 파일에 대해 텍스트 에디터로 파일을 열어서 프로젝트 명칭과 동일하게 문자열 수정


### 11.1.2 프로젝트 임포트
* 10.1.2 를 참고해서 프로젝트를 임포트한다.
  * 메뉴에서 **`File > Import`** 를 선택한 후 Import 창에서 **`General > Existing Projects Into Workspace`** 메뉴를 선택한다.
  * Browse 버튼을 통해 앞서 생성한 복사해서 생성한 Ex11_Valid_initBinder 프로젝트를 임포트한다.

### 11.1.3 디펜던시 추가
* 프로젝트를 복사했기 때문에 의존성은 직접 추가해주어야 한다.
* **`build.gradle`** 파일에 직접 입력해서 validation 관련 디펜던시를 추가해줄 수 있다.
```gradle
	implementation 'org.springframework.boot:spring-boot-starter-validation'
```
* 디펜던시 추가 후 정상 동작을 위해 update를 해준다.
  * build.gradle 우클릭 후 **`Gradle > Refresh Gradle Project`** 수행을 통해 dependency update 함

 ![](images/11-1.png)

### 11.1.4 약한 결합 적용

* 기존 예제 중 ContentValidator를 사용하는 부분이 강한 결합이므로 다음과 같이 수정해서 약한 결합으로 만들어준다.

* MyController.java

``` java
package com.study.springboot;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {
	
	@RequestMapping("/")
	public  @ResponseBody String root() throws Exception {
		return "Valid_initBinder (3)";  // 세 번째 예제 구분
	}

	@RequestMapping("/insertForm")
	public String insert1() {

		return "createPage";    // form 입력을 위한 :: createPage.jsp 호출
	}
	
    /*
    6. contentDto 에 대해 @Valid 어노테이션 지정을 통해 유효성 검증을 하겠다고 표시
    7. 파라미터로 객체 변수가 들어오면 스프링이 binder 변수에 저장된 객체를 통해 
       즉시 유효성 검사를 하고, 에러가 있으면 result 변수에 담아 둔다.
    */
	@RequestMapping("/create")
	public String insert2(@ModelAttribute("dto") @Valid ContentDto contentDto,
						BindingResult result)
	{
		String page = "createDonePage"; // form 입력 정상 :: createDonePage.jsp 호출
		System.out.println(contentDto);
		
//		ContentValidator validator = new ContentValidator();
//		validator.validate(contentDto, result);
		if ( result.hasErrors() ) {
			if ( result.getFieldError("writer") != null ) {
				System.out.println("1:" + result.getFieldError("writer").getCode());				
			}
			if ( result.getFieldError("content") != null ) {
				System.out.println("2:" + result.getFieldError("content").getCode());				
			}

			page = "createPage";    // 에러가 있는 경우 :: createPage.jsp 호출
		}

		return page;
	}
	
    /*
    1. @InitBinder 어노테이션 지정을 통해 해당 메서드를 프로젝트가 시작할 때 먼저 실행
    2. WebDataBinder 타입 변수(binder)에 우리가 사용할 유효성 검증 클래스
       (ContentValidator)가 프로젝트가 시작할 때 등록됨
    3. 프로젝트에서 사용할 빈을 등록하는 것과 비슷하지만 관리하는 곳을 다르게 지정한 것임
       -> 이게 무슨 의미인지? autowired 개념이 아닌 건가?
    4. 이후로는 개별적으로 생성할 필요 없이 유효성 검증이 필요하면 binder 변수에서 
       꺼내서 사용하면 된다.
    5. 다른 곳에서는 필요할 때마다 매번 new 로 만들지 않고 한 번 만들어놓은 것을 
       주입 받아 사용할 수 있게 되었으므로 약한 결합으로 사용할 수 있게 되었다.
    */
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.setValidator(new ContentValidator());
	}
}
```

### 11.1.5 테스트

* http://localhost:8081 실행 시 root() 메서드 호출되어 "Validator (3)" 결과만 반환

![](images/11-2.png)

* http://localhost:8081/insertForm 실행 후 유효성 검사 정상 처리 테스트

![](images/11-3.png)

* http://localhost:8081/insertForm 실행 후 유효성 검사 에러 처리 테스트

![](images/11-4.png)

* 콘솔 로그에 출력된 결과 참고

![](images/11-5.png) 
