# 09 Validator 사용하기

## 9.1 폼 데이터의 유효성 검증

### 9.1.1 클라이언트인 HTML 페이지에서 자바스크립트를 통한 검증
    - 데이터 유효성 검증되지 않은 경우 서버로 데이터를 보내지 않아 네트워크 트래픽 낭비를 막을 수 있음
    - 악의적인 URL 호출에 이해 검증되지 않은 데이터가 서버로 올라올 수 있음
 2. 서버 페이지인 JSP/Servlet 에서 파라미터로 받은 후 검증
 
 * 결국 유효성검증은 클라이언트/서버에서 모두 필요한 작업임.
 * 이 때, 스프링의 Validator를 통한 불편함 해소, 유효성체크의 일관성 제공
   

## 9.2 스프링 폼 데이터 유효성 검증 예제 만들기  
### 9.2.1 JSP 사용을 위한 프로젝트 기본형 만들기  

![](images/9-1.png)  
![](images/9-2.png)

 * 폼 데이터의 유효성 검증은 **`Spring Web`** 을 추가하면, 별도의 디펜던시 추가 없이도 사용 가능하다.

 * JSP 사용을 위한 의존성 추가 : **`build.gradle`** 파일 수정

![](images/9-3.png)

``` yaml
dependencies {
	implementation 'org.springframework.boot:spring-boot-starter-web'
	compileOnly 'org.projectlombok:lombok'
	annotationProcessor 'org.projectlombok:lombok'
	providedRuntime 'org.springframework.boot:spring-boot-starter-tomcat'
	testImplementation ('org.springframework.boot:spring-boot-starter-test') {
		exclude group: 'org.junit.vintage', module: 'junit-vintage-engine'
	}	
	implementation 'javax.servlet:jstl'
	implementation 'org.apache.tomcat.embed:tomcat-embed-jasper'
}
```
 * build.gradle 우클릭 후 **`Gradle > Refresh Gradle Project`** 수행을 통해 dependency update 함

 * **`application.properties`** 파일 내용 수정
``` properties
server.port=8081
# JSP 설정
spring.mvc.view.prefix=/WEB-INF/views/
spring.mvc.view.suffix=.jsp
```
 * JSP 사용을 위한 폴더 구조 생성, 리퀘스트 맵핑을 위한 MyConroller.java 클래스 작성 : `이전 예제 복사 후 수정하기`

### 9.2.2 **커맨드 객체와 유효성 검증 객체 만들기** : ContentDto.java, ContentVaidator.java 작성

![](images/9-4.png)


* Lombok 디펜던시를 이용해서 Getter/Setter 구현

![](images/9-5.png) 

* ContentValidator.java

``` java
package com.study.springboot;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/*
Validator 인터페이스를 구현하기 위해 support, validate 메서드를 반드시 구현해야 함
*/
public class ContentValidator implements Validator {

	@Override
	public boolean supports(Class<?> arg0) {
		return ContentDto.class.isAssignableFrom(arg0);	// 검증할 객체의 클래스 타입 정보
	}
	
	@Override
	public void validate(Object obj, Errors errors) {
		
        /*
        1. 모든 객체를 받아들이기 위해 Object 를 파라미터로 받음.
        2. 필요에 따라 각 형태 별로 형변환 해서 사용. 여기서는 ContentDto로 형변환
        3. 해당 객체에 대한 유효성 검증 로직을 하단에 구현함.
        4. 유효성 검증을 통과하지 못한 데이터는 errors 객체 변수에 내용을 담음.
        5. errors 객체에 담긴 내용은 다른 곳에서도 이용이 가능함.
        */
		ContentDto dto = (ContentDto)obj;
		
		String sWriter = dto.getWriter();
		if ( sWriter == null || sWriter.trim().isEmpty() ) {
			System.out.println("Writer is null or empty");
			errors.rejectValue("writer", "trouble");
		}
		
		String sContent = dto.getContent();
		if ( sContent == null || sContent.trim().isEmpty() ) {
			System.out.println("sContent is null or empty");
			errors.rejectValue("content", "trouble");
		}
		
	}
	
}
```
### 9.2.3 리퀘스트 맵핑

* MyController.java

``` java
package com.study.springboot;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {
	
	@RequestMapping("/")
	public  @ResponseBody String root() throws Exception {
		return "Validator (1)"; // 첫 번째 예제 구분
	}

	@RequestMapping("/insertForm")
	public String insert1() {

		return "createPage";  // form 입력을 위한 :: createPage.jsp 호출
	}
	
	@RequestMapping("/create")
	public String insert2(@ModelAttribute("dto") ContentDto contentDto,
						BindingResult result)
	{
		String page = "createDonePage"; // form 입력 정상 :: createDonePage.jsp 호출
		System.out.println(contentDto);
		    
		ContentValidator validator = new ContentValidator();  // 유효성 검증 객체 생성
		validator.validate(contentDto, result);
		if ( result.hasErrors() ) {
			page = "createPage";  // 에러가 있는 경우 :: createPage.jsp 호출
		}

		return page;
	}
}
```

### 9.2.4 뷰 만들기

* createPage.jsp

``` jsp
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-Type" content="text/html" charset="UTF-8">
<title>CreatePage</title>
</head>
<body>
createPage.jsp
<br/>

<%
	String conPath = request.getContextPath();
%>

<form action="<%=conPath%>/create">
	작성자 : <input type="text" name="writer" value="${dto.writer}"> <br/>
	내용 : <input type="text" name="content" value="${dto.content}"> <br/>
	<input type="submit" value="전송"> <br/>
</form>

</body>
</html>
```

* createDonePage.jsp

``` jsp
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-Type" content="text/html" charset="UTF-8">
<title>CreatePageDone</title>
</head>
<body>
createPageDone.jsp
<br/>

이름 : ${dto.writer} <br/>
내용 : ${dto.content} 

</body>
</html>
```

### 9.2.5 테스트

* http://localhost:8081 실행 시 root() 메서드 호출되어 "Validator (1)" 결과만 반환

* http://localhost:8081/insertForm 실행 시 데이터 입력을 위한 폼 화면이 출력

* 작성자와 내용을 모두 입력하거나 둘 중 하나를 입력하지 않는 등의 케이스로 테스트 후 
유효성 검증 여부에 대해 확인

* 콘솔 로그에 출력된 결과 참고

![](images/9-6.png) 